import { Task } from "./Task";

export class TaskScheduler {
    maxConcurrent: number;
    taskRunning: number[] = [];
    taskList: Task[];

    constructor(maxConcurrent: number) {
        this.maxConcurrent = maxConcurrent;
    }

    // Add task to the tasklist
    add_tasks(taskList: Task[]) {
        this.taskList = taskList;
    }

    run() {
        let min_duration = Infinity;
        let taskRunningIndex = 0;
        let min_duration_dependent = Infinity;

        // We are checking the dependency array length, if its 0 then we will check for the smallest value of duration with dependency array 
        //l length 0 and then add it to the executed list

        for (let i = 0; i < this.taskList.length; i++) {
            if (this.taskList[i].dependencies.length === 0) {
                if (this.taskList[i].duration < min_duration) {
                    min_duration = Math.min(this.taskList[i].duration, min_duration);
                }
                console.log(`Task ${min_duration} started`);
                this.taskRunning[taskRunningIndex] = min_duration;
                taskRunningIndex++;
                this.sleep(this.taskList[i].duration, this.taskList[i]);

            }

            // If the dependency length is greater than 0 and taskRunning is empty then we will return or else will add it to the 
            // array
            else if (this.taskList[i].dependencies.length > 0) {
                if(this.taskList[i].dependencies.indexOf(this.taskRunning[i]) !== -1)
                {
                    console.log(`The task is waiting for the executed task to be completed`);
                }
                else{
                    this.taskRunning[taskRunningIndex] = this.taskList[i].task_id;
                    taskRunningIndex++;
                    if (this.taskList[i].duration < min_duration_dependent) {
                        min_duration_dependent = Math.min(min_duration_dependent,this.taskList[i].duration);
                    }
                    console.log(`Task ${min_duration_dependent} started`);
                    this.sleep(this.taskList[i].duration,this.taskList[i]);
                    
                }
            }
        }

    }


    sleep(duration: number,taskList:Task) {
        setTimeout(() => {
            console.log(`Sleeped for ${duration}`);
            const serviceWorker = new ServiceWorker();
            // Create a new Thread and once the duration is completed, complete the tasks
            console.log(`The ${taskList} is Completed`);
        }, duration);
    }

}

const taskList1 = new Task(1,3,[1,2]);
const taskList2 = new Task(1,3,[]);
const taskList3 = new Task(1,3,[4]);
const taskList4 = new Task(1,3,[]);
const taskList:Task[]=[];
taskList.push(taskList1);
taskList.push(taskList2);
taskList.push(taskList3);
taskList.push(taskList4);

const taskScheduler = new TaskScheduler(3);
taskScheduler.add_tasks(taskList);
taskScheduler.run();