export class Task {
    task_id:number;
    duration:number;
    dependencies:number[];

    constructor(task_id:number,duration:number,dependencies:number[])
    {
        this.task_id=task_id;
        this.duration=duration;
        this.dependencies=dependencies;
    }

}